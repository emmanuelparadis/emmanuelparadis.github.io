library(ape)

###
### Chapter 3
###

x <- paste("AJ5345", 26:49, sep = "")
x <- c("Z73494", x)
sylvia.seq <- read.GenBank(x)
str(sylvia.seq)
write.dna(sylvia.seq, "sylviaseq.fas", format = "fasta")
###
### After aligning and saving under the interleaved format:
###
sylvia.seq.ali <- read.dna("sylviaseq.phy")
taxa.sylvia <- attr(sylvia.seq, "species")
names(taxa.sylvia) <- names(sylvia.seq)
rm(sylvia.seq)
taxa.sylvia[1] <- "Sylvia_atricapilla"
taxa.sylvia[24] <- "Sylvia_abyssinica"
taxa.sylvia
sylvia.eco <- read.table("sylvia_data.txt")
str(sylvia.eco)
rownames(sylvia.eco)
save(sylvia.seq.ali, taxa.sylvia, sylvia.eco,
     file = "sylvia.RData")

###
### Chapter 5
###

syl.K80 <- dist.dna(sylvia.seq.ali, pairwise.deletion = TRUE)
syl.F84 <- dist.dna(sylvia.seq.ali, model = "F84",
                     pairwise.deletion = TRUE)
syl.TN93 <- dist.dna(sylvia.seq.ali, model = "TN93",
                     pairwise.deletion = TRUE)
syl.GG95 <- dist.dna(sylvia.seq.ali, model = "GG95",
                     pairwise.deletion = TRUE)
round(cor(cbind(syl.K80, syl.F84, syl.TN93, syl.GG95)), 3)

syl.JC69 <- dist.dna(sylvia.seq.ali, model = "JC69",
                     pairwise.deletion = TRUE)
syl.raw <- dist.dna(sylvia.seq.ali, model = "raw",
                    pairwise.deletion = TRUE)
layout(matrix(1:2, 1))
plot(syl.JC69, syl.raw)
abline(b = 1, a = 0) # draw x = y line
plot(syl.K80, syl.JC69)
abline(b = 1, a = 0)

nj.sylvia.K80 <- nj(syl.K80)
nj.sylvia.F84 <- nj(syl.F84)
nj.sylvia.TN93 <- nj(syl.TN93)
nj.sylvia.GG95 <- nj(syl.GG95)
dist.topo(nj.sylvia.K80, nj.sylvia.F84)
dist.topo(nj.sylvia.K80, nj.sylvia.TN93)
dist.topo(nj.sylvia.K80, nj.sylvia.GG95)
dist.topo(nj.sylvia.F84, nj.sylvia.TN93)
dist.topo(nj.sylvia.F84, nj.sylvia.GG95)
dist.topo(nj.sylvia.TN93, nj.sylvia.GG95)
sylvia.cons <- consensus(nj.sylvia.K80, nj.sylvia.F84,
                         nj.sylvia.GG95, nj.sylvia.TN93)
sylvia.cons$tip.label <- taxa.sylvia[sylvia.cons$tip.label]
plot(sylvia.cons, no.margin = TRUE)
nj.boot.sylvia <- boot.phylo(phy = nj.sylvia.K80,
                             x = sylvia.seq.ali,
                             FUN = function(xx) nj(dist.dna(xx,
                               pairwise.deletion = TRUE)),
                             B = 200)
nj.boot.sylvia
nj.boot.sylvia.codon <- boot.phylo(nj.sylvia.K80,
                                   sylvia.seq.ali,
                                   function(xx) nj(dist.dna(xx,
                               pairwise.deletion = TRUE)),
                                   200, 3)
nj.boot.sylvia.codon
nj.est <- nj.sylvia.K80
nj.est$tip.label <- taxa.sylvia[nj.est$tip.label]
nj.est$node.label <- nj.boot.sylvia / 2
nj.est <- root(nj.est, "Chamaea_fasciata")
nodelabels(nj.est$node.label, bg = "white")
add.scale.bar(y = 0.5, length = 0.01)
write.tree(nj.est, "sylvia_nj_k80.tre")

###
### Chapter 6
###

tr <- read.tree("sylvia_nj_k80.tre")
tr <- drop.tip(tr, "Chamaea_fasciata")
DF <- sylvia.eco[tr$tip.label, ]
table(DF$geo.range, DF$mig.behav)
syl.er <- ace(DF$geo.range, tr, type = "d")
syl.er
syl.sym <- ace(DF$geo.range, tr, type = "d", model = "SYM")
syl.sym
1 - pchisq(2*(syl.sym$loglik - syl.er$loglik), 2)
mod <- matrix(0, 3, 3)
mod[2, 1] <- mod[1, 2] <- 1
mod[2, 3] <- mod[3, 2] <- 2
mod
syl.mod <- ace(DF$geo.range, tr, type = "d", model = mod)
syl.mod
Q <- matrix(0, 3, 3)
Q[1, 2] <- Q[2, 1] <- syl.sym$rates[1]
Q[1, 3] <- Q[3, 1] <- syl.sym$rates[2]
Q[2, 3] <- Q[3, 2] <- syl.sym$rates[3]
Q
diag(Q) <- -rowSums(Q)
Q
library(rmutil)
P <- mexp(0.05 * Q)
rownames(P) <- c("temp", "temptrop", "trop")
colnames(P) <- c("temp", "temptrop", "trop")
round(P, 3)
co <- rep("grey", 24)
co[DF$geo.range == "temp"] <- "black"
co[DF$geo.range == "trop"] <- "white"
plot(tr, "c", FALSE, no.margin = TRUE, label.offset = 1)
tiplabels(pch = 22, bg = co, cex = 2, adj = 1)
nodelabels(thermo = syl.sym$lik.anc,
           bg = c("black", "grey", "white"), cex = 0.8)
