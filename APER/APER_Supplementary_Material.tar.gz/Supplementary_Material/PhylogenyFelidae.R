library(ape)

###
### Chapter 3
###

x <- paste("AF006", seq(387, 459, 2), sep = "")
felidseq16S <- read.GenBank(x)
table(unlist(lapply(felidseq16S, length)))
str(felidseq16S[1:5])
write.dna(felidseq16S, "felidseq16S.fas", format = "fasta")
taxa.felid <- attr(felidseq16S, "species")
names(taxa.felid) <- names(felidseq16S)
###
### After aligning and saving under the interleaved format:
###
felidseq16Sali <- read.dna("felidseq16S.phy")
table(unlist(lapply(felidseq16Sali, length)))
DF <- read.table("felid_bodymass.txt")
felid.body.mass <- DF$V2
names(felid.body.mass) <- DF$V1
felid.body.mass
save(felidseq16Sali, taxa.felid, felid.body.mass,
     file = "felid.RData")

###
### Chapter 5
###

phymltest.felid <- phymltest("felidseq16S.phy",
                             execname = "phyml_linux")
phymltest.felid
summary(phymltest.felid)
plot(phymltest.felid)
tr <- read.tree("felidseq16S.phy_phyml_tree.txt")
mltree.felid <- tr[[28]]
mltree.felid$tip.label <- taxa.felid[mltree.felid$tip.label]
mltree.felid <- root(mltree.felid, "Galidia_elegans")
mltree.felid <- drop.tip(mltree.felid, c("Crocuta_crocuta",
                                  "Galidia_elegans"))
plot(mltree.felid)
add.scale.bar(length = 0.01)

felid.chrono <- chronogram(mltree.felid, scale = 12.5)
par(mar = c(2, 0, 0, 0))
plot(felid.chrono, cex = 0.8)
axisPhylo()
write.tree(felid.chrono, "felid.chrono.tre")

###
### Chapter 6
###

tr <- read.tree("felid.chrono.tre")
yule(tr)
birthdeath(tr)
1 - pchisq(2*(8.405339 - 7.349097), 1)
IN <- tr$tip.label %in% names(felid.body.mass)
tr$tip.label[!IN]
names(felid.body.mass)[36]
names(felid.body.mass)[36] <- "Prionailurus_rubiginosa"
x <- rep(3500, 2)
names(x) <-  c("Felis_catus", "Felis_libyca")
felid.body.mass <- c(felid.body.mass, x)
all(tr$tip.label %in% names(felid.body.mass))

range(felid.body.mass)
X <- scale(log(felid.body.mass[tr$tip.label]), scale=FALSE)
range(X)
X.node <- ace(X, tr)$ace
yule.cov(tr, ~ c(X, X.node))

x <- seq(-2, 3, 0.05)
lambda <- 1 / (1 + exp(-(-0.1615685 * x + -1.1870642)))
ox <- exp(x + mean(log(felid.body.mass[tr$tip.label])))
plot(ox, lambda, type = "l", xlab = "Body mass (g)",
     ylab = expression("Predicted "*lambda))
rug(felid.body.mass[tr$tip.label])
