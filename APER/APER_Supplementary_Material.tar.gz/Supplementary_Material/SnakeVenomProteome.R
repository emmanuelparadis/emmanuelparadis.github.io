library(seqinr)

###
### Chapter 3
###

venom.no <- read.table("venom_factorV.txt",
                       as.is = TRUE, header = TRUE)
venom.no[1:2, ]
s <- choosebank("swissprot")
query(s$socket, "venom", "ac=Q7SZN0")
X <- getSequence(venom$req[[1]])
X[1:20]
query(s$socket, "venom", "ac=Q9BQS7 OU ac=Q9Z0Z4")
paste("ac", venom.no$No, sep = "=")
paste("ac", venom.no$No[1:4], sep = "=", collapse = " OU ")
no4query <- paste("ac=", venom.no$No, sep = "",
                  collapse = " OU ")
query(s$socket, "venom", no4query)
venom.seq <- lapply(venom$req, getSequence)
str(venom.seq)
names(venom.seq) <- venom.no$No
