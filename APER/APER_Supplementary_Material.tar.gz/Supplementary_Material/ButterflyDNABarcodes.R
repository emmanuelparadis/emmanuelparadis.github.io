library(ape)

###
### Chapter 3
###

x <- paste("AY66", 6597:7060, sep = "")
x <- c(x, "AY724411", "AY724412")
astraptes.seq <- read.GenBank(x)
table(unlist(lapply(astraptes.seq, length)))
write.dna(astraptes.seq, "astraptesseq.fas", format = "fasta")
###
### After aligning and saving under the interleaved format:
###
astraptes.seq.ali <- read.dna("astraptesseq.phy")
table(attr(astraptes.seq, "species"))
taxa.astraptes <- attr(astraptes.seq, "species")
names(taxa.astraptes) <- names(astraptes.seq)
save(astraptes.seq.ali, taxa.astraptes,
     file = "astraptes.RData")
###
### Chapter 5
###

M.astraptes.K80 <- dist.dna(astraptes.seq.ali,
                        pairwise.deletion = TRUE)
summary(M.astraptes.K80)
summary(dist.dna(astraptes.seq.ali))
hist(M.astraptes.K80)

tr <- nj(M.astraptes.K80)
tr$tip.label <- taxa.astraptes[tr$tip.label]
