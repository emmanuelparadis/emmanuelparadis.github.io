library(ape)

###
### Chapter 3
###

mtgen.taxa <- read.table("mammal_mtGenome.fasta", skip = 4,
			 nrows = 109, sep = "_", comment.char = "(",
			 as.is = TRUE)
mtgen.taxa[1:5, ]
mtgen.taxa$V3 <- NULL
mtgen.taxa$V1 <- gsub("#", "", mtgen.taxa$V1)
mtgen.taxa$V1 <- gsub(" : ", "", mtgen.taxa$V1)
colnames(mtgen.taxa) <- c("code", "species")
mtgen.taxa[1:5, ]
mtgen <- read.dna("mammal_mtGenome.fasta",
		  format = "fasta", skip = 115)
length(mtgen)
names(mtgen)[1:10]
genes <- gsub("^[[:alnum:]]{1,}\\(", "", names(mtgen))
genes <- gsub("\\)$", "", genes)
unique(genes)[11]
i <- grep("Sequence does not exist", names(mtgen))
mtgen <- mtgen[-i]
genes <- gsub("^[[:alnum:]]{1,}\\(", "", names(mtgen))
genes <- gsub("\\)$", "", genes)
table(genes)

BF.sp <- matrix(NA, nrow = 109, ncol = 4)
rownames(BF.sp) <- mtgen.taxa$species
colnames(BF.sp) <- c("A", "C", "G", "T")
for (i in 1:109) {
  x <- grep(mtgen.taxa$code[i], names(mtgen))
  BF.sp[i, ] <- base.freq(mtgen[x])
}
matplot(BF.sp, type = "l", col = 1, xlab = "Species",
        ylab = "Base frequency")
legend(0, 0.23, c("A", "C", "G", "T"), lty = 1:4, bty = "n")

BF.gene <- matrix(NA, nrow = 37, ncol = 4)
rownames(BF.gene) <- unique(genes)
colnames(BF.gene) <- c("A", "C", "G", "T")
for (i in 1:37) {
    x <- grep(rownames(BF.gene)[i], names(mtgen), fixed = TRUE)
    BF.gene[i, ] <- base.freq(mtgen[x])
}
par(mar = c(8, 3, 3, 2))
barplot(t(BF.gene), las = 2, legend = TRUE)

cytb <- mtgen[grep("CYTB", names(mtgen))]
table(unlist(lapply(cytb, length)))
cytb1 <- lapply(cytb, function(x) x[c(TRUE, FALSE, FALSE)])
cytb2 <- lapply(cytb, function(x) x[c(FALSE, TRUE, FALSE)])
cytb3 <- lapply(cytb, function(x) x[c(FALSE, FALSE, TRUE)])
BF.cytb <- matrix(NA, 3, 4)
rownames(BF.cytb) <- c("1st codon position",
                       "2nd codon position",
                       "3rd codon position")
colnames(BF.cytb) <- c("A", "C", "G", "T")
BF.cytb[1, ] <- base.freq(cytb1)
BF.cytb[2, ] <- base.freq(cytb2)
BF.cytb[3, ] <- base.freq(cytb3)
BF.cytb
barplot(t(BF.cytb), main = "Cytochrome b",
        ylab = "Base frequency")
text(0.7, BF.cytb[1, 1]/2, "A", cex = 2)
text(0.7, BF.cytb[1, 1] + BF.cytb[1, 2]/2, "C", cex = 2)
text(0.7, sum(BF.cytb[1, 1:2])+BF.cytb[1, 3]/2, "G", cex = 2)
text(0.7, sum(BF.cytb[1, 1:3])+BF.cytb[1, 4]/2, "T", cex = 2)
